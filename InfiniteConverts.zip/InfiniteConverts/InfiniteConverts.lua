local old_init = UpgradesTweakData._init_pd2_values
function UpgradesTweakData:_init_pd2_values()
old_init(self)
 
self.values.player.convert_enemies_max_minions = {
		100,
		101
	}
	
end